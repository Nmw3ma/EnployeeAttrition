

<?php $__env->startSection('meta'); ?>
    <title>Schedule | Workday Time Clock</title>
    <meta name="description" content="Workday Schedule">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12 page-header">
            <h2 class="page-title">
                <?php echo e(__("Schedule")); ?>


                <a href="<?php echo e(url('/admin/schedule/add')); ?>" class="btn btn-outline-primary btn-sm float-right">
                    <i class="fas fa-plus"></i><span class="button-with-icon"><?php echo e(__("Add")); ?></span>
                </a>
            </h2>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <table width="100%" class="table datatables-table custom-table-ui" data-order='[[ 0, "desc" ]]'>
                <thead>
                    <tr>
                        <th><?php echo e(__('Employee')); ?></th>
                        <th><?php echo e(__('Start')); ?>/<?php echo e(__("Off Time")); ?></th>
                        <th><?php echo e(__('Total Hours')); ?></th>
                        <th><?php echo e(__('Rest Days')); ?></th>
                        <th><?php echo e(__('From')); ?></th>
                        <th><?php echo e(__('Until')); ?></th>
                        <th><?php echo e(__('Status')); ?></th>
                        <th><?php echo e(__('Actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($schedule)): ?>
                        <?php $__currentLoopData = $schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->employee); ?></td>
                            <td>
                                <?php
                                    if($time_format == 12) {
                                        echo e(date("h:i A", strtotime($data->intime)));
                                        echo " - ";
                                        echo e(date("h:i A", strtotime($data->outime)));
                                    } else {
                                        echo e(date("H:i", strtotime($data->intime)));
                                        echo " - ";
                                        echo e(date("H:i", strtotime($data->outime)));
                                    }
                                ?>
                            </td>
                            <td><?php echo e($data->hours); ?> hr</td>
                            <td><?php echo e($data->restday); ?></td>
                            <td><?php echo e(date('D, M d, Y', strtotime($data->datefrom))) ?></td>
                            <td><?php echo e(date('D, M d, Y', strtotime($data->dateto))) ?></td>
                            <td>
                                <?php if($data->archive == '0'): ?> 
                                    <span class="green"><?php echo e(__('Active')); ?></span>
                                <?php else: ?>
                                    <span class="teal"><?php echo e(__('Archived')); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="text-right">
                                <?php if($data->archive == '0'): ?> 
                                    <a href="<?php echo e(url('admin/schedule/edit/')); ?>/<?php echo e($data->id); ?>" class="btn btn-outline-secondary btn-sm btn-rounded"><i class="fas fa-pen"></i></a>
                                    <a href="<?php echo e(url('admin/schedule/archive/')); ?>/<?php echo e($data->id); ?>" class="btn btn-outline-secondary btn-sm btn-rounded"><i class="fas fa-archive"></i></a>
                                    <a href="<?php echo e(url('admin/schedule/delete/')); ?>/<?php echo e($data->id); ?>" class="btn btn-outline-secondary btn-sm btn-rounded"><i class="fas fa-trash"></i></a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('admin/schedule/delete/')); ?>/<?php echo e($data->id); ?>" class="btn btn-outline-secondary btn-sm btn-rounded"><i class="fas fa-trash"></i></a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <!-- <small class="text-muted"><?php echo e(__("Only 250 recent records will be displayed use Date range filter to get more records")); ?></small> -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/initiate-datatables-with-search.js')); ?>"></script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CEO\Desktop\Emman\Students\Pending\Terry\employee_attr\resources\views/admin/schedule.blade.php ENDPATH**/ ?>