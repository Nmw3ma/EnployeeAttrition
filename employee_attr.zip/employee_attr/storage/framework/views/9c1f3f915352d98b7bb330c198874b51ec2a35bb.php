<!doctype html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->yieldContent('meta'); ?>
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('/assets/images/img/favicon-16x16.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('/assets/images/img/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('/assets/images/img/favicon.ico')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <?php echo $__env->yieldContent('styles'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/css/auth.css')); ?>">
</head>
<body>
    <div class="wrapper">
        <?php echo $__env->yieldContent('auth'); ?>
    </div>

    <script src="<?php echo e(asset('/assets/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/validate-form.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\CEO\Desktop\Emman\Students\Pending\Terry\employee_attr\resources\views/layouts/auth.blade.php ENDPATH**/ ?>