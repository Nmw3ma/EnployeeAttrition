

<?php $__env->startSection('meta'); ?>
    <title>Manage Leave Groups | Workday Time Clock</title>
    <meta name="description" content="Workday Manage Leave Groups">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12 page-header">
            <h2 class="page-title">
                <?php echo e(__("Manage Leave Groups")); ?>


                <a href="<?php echo e(url('admin/leavegroups/add')); ?>" class="btn btn-outline-primary btn-sm float-right">
                    <i class="fas fa-plus"></i><span class="button-with-icon"><?php echo e(__("Add")); ?></span>
                </a>
            </h2>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <table width="100%" class="table datatables-table custom-table-ui" data-order='[[ 0, "desc" ]]'>
                <thead>
                    <tr>
                        <th><?php echo e(__("Leave Group")); ?></th>
                        <th><?php echo e(__("Description")); ?></th>
                        <th><?php echo e(__("Privilege")); ?></th>
                        <th><?php echo e(__("Status")); ?></th>
                        <th><?php echo e(__("Actions")); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($leavegroups)): ?> 
                        <?php $__currentLoopData = $leavegroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($lg->leavegroup); ?></td>
                            <td><?php echo e($lg->description); ?></td>
                            <td>
                                <?php if(isset($leavetypes)): ?>
                                    <?php $__currentLoopData = $leavetypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <?php
                                            $leavegroup = explode(",",$lg->leaveprivileges);
                                            foreach ($leavegroup as $value) 
                                            {
                                                if($value == $lt->id)
                                                {
                                                    echo $lt->leavetype.", ";
                                                }
                                            }
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                            <td><?php if($lg->status == 1): ?> Active <?php else: ?> Disabled <?php endif; ?></td>
                            <td class="text-right">
                                <a href="<?php echo e(url('admin/leavegroups/edit')); ?>/<?php echo e($lg->id); ?>" class="btn btn-outline-secondary btn-sm btn-rounded"><i class="fas fa-pen"></i></a>

                                <a href="<?php echo e(url('admin/leavegroups/delete')); ?>/<?php echo e($lg->id); ?>" class="btn btn-outline-secondary btn-sm btn-rounded"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/initiate-datatables-with-search.js')); ?>"></script> 
    <script src="<?php echo e(asset('/assets/js/initiate-toast.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CEO\Desktop\Emman\Students\Pending\Terry\employee_attr\resources\views/admin/leavegroups.blade.php ENDPATH**/ ?>