

<?php $__env->startSection('meta'); ?>
    <title>User Accounts | Workday Time Clock</title>
    <meta name="description" content="Workday User Accounts">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12 page-header">
            <h2 class="page-title">
                <?php echo e(__("User Accounts")); ?>


                <a href="<?php echo e(url('export/report/accounts')); ?>" class="btn btn-outline-secondary btn-sm mr-2 float-right">
                    <i class="fas fa-download"></i><span class="button-with-icon"><?php echo e(__("Export to CSV")); ?></span>
                </a>

                <a href="<?php echo e(url('admin/reports')); ?>" class="btn btn-outline-primary btn-sm mr-2 float-right">
                    <i class="fas fa-arrow-left"></i><span class="button-with-icon"><?php echo e(__("Return")); ?></span>
                </a>
            </h2>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <table width="100%" class="table datatables-table" id="dataTables-example" data-order='[[ 0, "asc" ]]'>
                <thead>
                    <tr>
                        <th><?php echo e(__("Employee Name")); ?></th>
                        <th><?php echo e(__("Email")); ?></th>
                        <th><?php echo e(__("Account Type")); ?></th>
                        <th><?php echo e(__("Status")); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($users)): ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($data->name); ?></td>
                                <td><?php echo e($data->email); ?></td>
                                <td><?php if( $data->acc_type == 2): ?> Admin <?php else: ?> Employee <?php endif; ?></td>
                                <td><?php if($data->status == 1): ?> Active <?php endif; ?> <?php if($data->status == 0): ?> Disabled <?php endif; ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/initiate-datatables-with-search.js')); ?>"></script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CEO\Desktop\Emman\Students\Pending\Terry\employee_attr\resources\views/admin/reports-users.blade.php ENDPATH**/ ?>