

<?php $__env->startSection('meta'); ?>
    <title>Reports | Employee Attrition Prediction</title>
    <meta name="description" content="Workday Reports">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12 page-header">
            <h2 class="page-title">
                <?php echo e(__("Reports")); ?>

            </h2>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <table width="100%" class="table datatables-table" data-order='[[ 0, "asc" ]]'>
                <thead>
                    <tr>
                        <th><?php echo e(__('Report Name')); ?></th>
                        <th><?php echo e(__('Last Viewed')); ?></th>
                    </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><a href="<?php echo e(url('admin/reports/employee-list')); ?>"><i class="fas fa-users"></i> <?php echo e(__('Employee List Report')); ?></a></td>
                    <td>
                        <?php if(isset($lastviews)): ?>
                            <?php $__currentLoopData = $lastviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $views): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($views->report_id == 1): ?>
                                    <?php echo e($views->last_viewed); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </td>
                </tr>
                
                
                <tr>
                    <td><a href="<?php echo e(url('admin/reports/company-overview')); ?>"><i class="fas fa-chart-pie"></i> <?php echo e(__("Company Overview")); ?></a></td>
                    <td>
                        <?php if(isset($lastviews)): ?>
                            <?php $__currentLoopData = $lastviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $views): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($views->report_id == 5): ?>
                                    <?php echo e($views->last_viewed); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td><a href="<?php echo e(url('admin/reports/employee-birthdays')); ?>"><i class="fas fa-birthday-cake"></i> <?php echo e(__('Employee Birthdays')); ?></a></td>
                    <td>
                        <?php if(isset($lastviews)): ?>
                            <?php $__currentLoopData = $lastviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $views): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($views->report_id == 7): ?>
                                    <?php echo e($views->last_viewed); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td><a href="<?php echo e(url('admin/reports/user-accounts')); ?>"><i class="fas fa-address-book"></i> <?php echo e(__('Attrition Reports')); ?></a></td>
                    <td>
                        <?php if(isset($lastviews)): ?>
                            <?php $__currentLoopData = $lastviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $views): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($views->report_id == 6): ?>
                                    <?php echo e($views->last_viewed); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/initiate-datatables.js')); ?>"></script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CEO\Desktop\Emman\Students\Pending\Terry\employee_attr\resources\views/admin/reports.blade.php ENDPATH**/ ?>