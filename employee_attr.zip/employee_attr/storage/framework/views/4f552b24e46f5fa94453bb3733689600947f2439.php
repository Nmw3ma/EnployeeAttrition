

<?php $__env->startSection('meta'); ?>
    <title>Manage Job Title Names | Workday Time Clock</title>
    <meta name="description" content="Workday Manage Job Title Names">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12 page-header">
            <h2 class="page-title">
                <?php echo e(__("Manage Job Title Names")); ?>

            </h2>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(url('admin/jobtitle/add')); ?>" method="post" class="needs-validation" autocomplete="off" novalidate accept-charset="utf-8">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="jobtitle"><?php echo e(__("Job Title Name")); ?></label>
                            <input type="text" name="jobtitle" value="" class="form-control text-uppercase" required>
                        </div>

                        <div class="form-group mb-0 text-right">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-check-circle"></i><span class="button-with-icon"><?php echo e(__("Save")); ?></span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <table width="100%" class="table datatables-table custom-table-ui" data-order='[[ 0, "desc" ]]'>
                        <thead>
                            <tr>
                                <th><?php echo e(__("Job Title")); ?></th>
                                <th><?php echo e(__("Actions")); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($data)): ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobtitle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($jobtitle->jobtitle); ?></td>
                                    <td class="text-right"> 
                                        <a href="<?php echo e(url('admin/jobtitle/delete')); ?>/<?php echo e($jobtitle->id); ?>" class="btn btn-outline-secondary btn-sm btn-rounded"><i class="fas fa-trash"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/initiate-datatables-with-search.js')); ?>"></script> 
    <script src="<?php echo e(asset('/assets/js/validate-form.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/initiate-toast.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CEO\Desktop\Emman\Students\Pending\Terry\employee_attr\resources\views/admin/jobtitle.blade.php ENDPATH**/ ?>