

<?php $__env->startSection('meta'); ?>
    <title>My Account | Employee Attrition Prediction</title>
    <meta name="description" content="Workday My Account">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12 page-header">
            <h2 class="page-title">
                <?php echo e(__("My Account")); ?>

            </h2>
        </div>
    </div>

    <div class="card">
        <div class="card-body">

            <br>
            <div class="row">
                <div class="col-md-4">
                    <h3><?php echo e(__("Profile")); ?></h3>
                    <p><?php echo e(__("Your name and email address are your identity on Workday and is used to login")); ?></p>
                </div>
                <div class="col-md-6">
                    <form action="<?php echo e(url('admin/update/user')); ?>" method="post" class="needs-validation" novalidate autocomplete="off" accept-charset="utf-8">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name"><?php echo e(__("Name")); ?></label>
                            <input type="text" name="name" value="<?php if(isset($myuser->name)): ?><?php echo e($myuser->name); ?><?php endif; ?>" placeholder="Name" class="form-control text-uppercase" required>
                        </div>
                        <div class="form-group">
                            <label for="email"><?php echo e(__("Email address")); ?></label>
                            <input type="email" name="email" value="<?php if(isset($myuser->email)): ?><?php echo e($myuser->email); ?><?php endif; ?>" placeholder="Email Address" class="form-control text-lowercase" required>
                        </div>
                        <div class="form-group text-right">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-check-circle"></i><span class="button-with-icon"><?php echo e(__("Update Profile")); ?></span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            <br>
            <br>
            <div class="line"></div>
            <br>
            <br>
            <div class="row">
                <div class="col-md-4">
                    <h3><?php echo e(__("Password")); ?></h3>
                    <p><?php echo e(__("Changing your password will also reset your API key")); ?></p>
                </div>
                <div class="col-md-6">
                    <form action="<?php echo e(url('admin/update/password')); ?>" method="post" class="needs-validation" novalidate autocomplete="off" accept-charset="utf-8">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="password"><?php echo e(__("Current Password")); ?></label>
                            <input type="password" name="currentpassword" placeholder="Current Password" class="form-control" required>
                        </div>

                        <div class="line"></div><br>
                        <div class="form-group">
                            <label for="password"><?php echo e(__("New Password")); ?></label>
                            <input type="password" name="newpassword" placeholder="Enter a new password" class="form-control" required>
                            <small class="form-text"><?php echo e(__("Password must be 6 or more characters")); ?></small>
                        </div>

                        <div class="form-group">
                            <label for="confirm_password"><?php echo e(__("Confirm New Password")); ?></label>
                            <input type="password" name="confirmpassword" placeholder="Enter the password again" class="form-control" required>
                        </div>

                        <div class="form-group text-right">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-check-circle"></i><span class="button-with-icon"><?php echo e(__("Change Password")); ?></span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            <br>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('/assets/js/validate-form.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/initiate-toast.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CEO\Desktop\Emman\Students\Pending\Terry\employee_attr\resources\views/admin/account.blade.php ENDPATH**/ ?>