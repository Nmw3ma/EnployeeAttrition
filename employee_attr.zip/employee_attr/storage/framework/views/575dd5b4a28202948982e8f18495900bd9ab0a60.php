

<?php $__env->startSection('meta'); ?>
    <title>Add Leave Group | Workday Time Clock</title>
    <meta name="description" content="Workday Add Leave Group">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12 page-header">
            <h2 class="page-title">
                <?php echo e(__("Add Leave Group")); ?>


                <a href="<?php echo e(url('/admin/leavegroups')); ?>" class="btn btn-outline-primary btn-sm float-right">
                    <i class="fas fa-arrow-left"></i><span class="button-with-icon"><?php echo e(__("Return")); ?></span>
                </a>
            </h2>
        </div>
    </div>

    <div class="card">
        <form action="<?php echo e(url('admin/leavegroups/store')); ?>" method="post" class="needs-validation" autocomplete="off" novalidate accept-charset="utf-8">
            <?php echo csrf_field(); ?>
            <div class="card-header"></div>
            <div class="card-body">
                <div class="form-group">
                    <label for="leavegroup"><?php echo e(__("Leave Group Name")); ?></label>
                    <input type="text" name="leavegroup" value="" class="form-control text-uppercase" required>
                </div>

                <div class="form-group">
                    <label for="description"><?php echo e(__("Description")); ?></label>
                    <input type="text" name="description" value="" class="form-control text-uppercase" required>
                </div>

                <div class="form-group">
                    <label for="leaveprivileges"><?php echo e(__('Leave Privileges')); ?></label>
                    <?php if(isset($leavetypes)): ?>
                    <div class="row">
                    <?php $__currentLoopData = $leavetypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                            <div class="custom-control custom-checkbox">
                              <input type="checkbox" name="leaveprivileges[]" value="<?php echo e($leave->id); ?>" class="custom-control-input" id="customCheck<?php echo e($leave->id); ?>">
                              <label class="custom-control-label" for="customCheck<?php echo e($leave->id); ?>"><?php echo e($leave->leavetype); ?></label>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                </div>
               
               <div class="form-group">
                  <label for="status"><?php echo e(__("Status")); ?></label>
                  <select name="status" class="custom-select" required>
                    <option value="" disabled selected>Choose...</option>
                    <option value="1"><?php echo e(__("Active")); ?></option>
                    <option value="0"><?php echo e(__("Disabled")); ?></option>
                  </select>
                </div>
            </div>
            <div class="card-footer text-right">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-check-circle"></i><span class="button-with-icon"><?php echo e(__("Save")); ?></span>
                </button>
                <a href="<?php echo e(url('/admin/leavegroups')); ?>" class="btn btn-secondary">
                    <i class="fas fa-times-circle"></i><span class="button-with-icon"><?php echo e(__("Cancel")); ?></span>
                </a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('/assets/js/validate-form.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/initiate-toast.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CEO\Desktop\Emman\Students\Pending\Terry\employee_attr\resources\views/admin/leavegroups-add.blade.php ENDPATH**/ ?>