

<?php $__env->startSection('meta'); ?>
    <title>Attrition Prediction </title>
    <meta name="description" content="Workday Attendance">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12 page-header">
            <h2 class="page-title">
                <?php echo e(__("Attrition Prediction")); ?>


                <a href="<?php echo e(url('/admin/attrition/manual-entry')); ?>" class="btn btn-outline-primary btn-sm float-right">
                    <i class="fas fa-plus"></i><span class="button-with-icon"><?php echo e(__("Predict New Employee Attrition")); ?></span>
                </a>
                
            </h2>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(url('admin/attendance')); ?>" method="post" class="form-inline responsive-filter-form needs-validation mb-2" novalidate autocomplete="off" accept-charset="utf-8">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="start" class="mr-2"><?php echo e(__("Date Range")); ?></label>
                    <input name="start" type="date" class="form-control form-control-sm mr-1" value="" required>
                </div>
                <div class="form-group">
                    <input name="end" type="date" class="form-control form-control-sm mr-1" value="" required>
                </div>
                <div class="form-group">
                    <button class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-filter"></i><span class="button-with-icon"><?php echo e(__("Filter")); ?></span>
                    </button>
                </div>
            </form>

            <table width="100%" class="table datatables-table custom-table-ui" data-order='[[ 0, "desc" ]]'>
                <thead>
                    <tr>
                        <th><?php echo e(__('Date')); ?></th>
                        <th><?php echo e(__('Employee')); ?></th>
                       
                        <th><?php echo e(__('Status')); ?> (<?php echo e(__("Churn")); ?>/<?php echo e(__("Not Churn")); ?>)</th>
                        <th><?php echo e(__('Actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($attritions)): ?>
                    <?php $__currentLoopData = $attritions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->created_at); ?></td>
                        <td><?php echo e($data->employee_id); ?></td>
                        <td>
                            <?php 
                                if($data->churn_status == 0) {
                                   echo "NOT CHURN";
                                } else {
                                  echo "CHURN"; 
                                }
                            ?>
                        </td>
                   
                        <td class="text-right">
                            <a href="<?php echo e(url('/admin/attendance/delete')); ?>/<?php echo e($data->id); ?>" class="btn btn-outline-secondary btn-sm btn-rounded"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <small class="text-muted"><?php echo e(__("Only 250 recent records will be displayed use Date range filter to get more records")); ?></small>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/initiate-datatables.js')); ?>"></script> 
    <script src="<?php echo e(asset('/assets/js/initiate-toast.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CEO\Desktop\Emman\Students\Pending\Terry\employee_attr\resources\views/admin/attrition.blade.php ENDPATH**/ ?>