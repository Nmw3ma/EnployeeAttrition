

<?php $__env->startSection('meta'); ?>
    <title>Employee | Workday Time Clock</title>
    <meta name="description" content="Workday Employee">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12 page-header">
            <h2 class="page-title">
                <?php echo e(__("Employee")); ?>


                <a href="<?php echo e(url('/admin/employee/add')); ?>" class="btn btn-outline-primary btn-sm float-right">
                    <i class="fas fa-plus"></i><span class="button-with-icon"><?php echo e(__("Add")); ?></span>
                </a>
            </h2>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <table width="100%" class="table datatables-table custom-table-ui" data-order='[[ 0, "desc" ]]'>
                <thead>
                    <tr>
                        <th><?php echo e(__('ID')); ?></th> 
                        <th><?php echo e(__('Employee')); ?></th> 
                        <th><?php echo e(__('Company')); ?></th>
                        <th><?php echo e(__('Department')); ?></th>
                        <th><?php echo e(__('Position')); ?></th>
                        <th><?php echo e(__('Status')); ?></th>
                        <th><?php echo e(__('Actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($employees)): ?>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($employee->idno); ?></td>
                            <td><?php echo e($employee->lastname); ?>, <?php echo e($employee->firstname); ?></td>
                            <td><?php echo e($employee->company); ?></td>
                            <td><?php echo e($employee->department); ?></td>
                            <td><?php echo e($employee->jobposition); ?></td>
                            <td><span class="text-uppercase"><?php if($employee->employmentstatus == 'Active'): ?> Active <?php else: ?> Archived <?php endif; ?></span></td>
                            <td class="text-right">
                                <a href="<?php echo e(url('/admin/employee/view')); ?>/<?php echo e($employee->reference); ?>" class="btn btn-outline-secondary btn-sm btn-rounded"><i class="fas fa-file-alt"></i></a>

                                <a href="<?php echo e(url('/admin/employee/edit')); ?>/<?php echo e($employee->reference); ?>" class="btn btn-outline-secondary btn-sm btn-rounded"><i class="fas fa-pen"></i></a>

                                <a href="<?php echo e(url('/admin/employee/archive')); ?>/<?php echo e($employee->reference); ?>" class="btn btn-outline-secondary btn-sm btn-rounded"><i class="fas fa-archive"></i></a>

                                <a href="<?php echo e(url('/admin/employee/delete')); ?>/<?php echo e($employee->reference); ?>" class="btn btn-outline-secondary btn-sm btn-rounded"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <!-- <small class="text-muted"><?php echo e(__("Only 250 recent records will be displayed use Date range filter to get more records")); ?></small> -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/initiate-datatables-with-search.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/initiate-toast.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CEO\Desktop\Emman\Students\Pending\Terry\employee_attr\resources\views/admin/employee.blade.php ENDPATH**/ ?>