

<?php $__env->startSection('meta'); ?>
    <title>User Roles | Workday Time Clock</title>
    <meta name="description" content="Workday User Roles">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12 page-header">
            <h2 class="page-title">
                <?php echo e(__("User Roles")); ?>


                <a href="<?php echo e(url('admin/user/roles/add')); ?>" class="btn btn-outline-primary btn-sm float-right">
                    <i class="fas fa-plus"></i><span class="button-with-icon"><?php echo e(__("Add")); ?></span>
                </a>

                <a href="<?php echo e(url('/admin/users')); ?>" class="btn btn-outline-primary btn-sm float-right mr-1">
                    <i class="fas fa-arrow-left"></i><span class="button-with-icon"><?php echo e(__("Return")); ?></span>
                </a>
            </h2>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <table width="100%" class="table datatables-table custom-table-ui" data-order='[[ 0, "desc" ]]'>
                <thead>
                    <tr>
                        <th><?php echo e(__("Role Name")); ?></th>
                        <th><?php echo e(__("Status")); ?></th>
                        <th><?php echo e(__("Actions")); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($roles)): ?>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($role->role_name); ?></td>
                            <td><?php echo e($role->status); ?></td>
                            <td class="text-right">
                                <a href="<?php echo e(url('/admin/user/roles/permission/edit')); ?>/<?php echo e($role->id); ?>" class="btn btn-outline-secondary btn-sm btn-rounded">
                                    <i class="fas fa-tasks"></i>
                                </a>

                                <a href="<?php echo e(url('/admin/user/roles/edit')); ?>/<?php echo e($role->id); ?>" class="btn btn-outline-secondary btn-sm btn-rounded">
                                    <i class="fas fa-pen"></i>
                                </a>

                                <a href="<?php echo e(url('/admin/user/roles/delete')); ?>/<?php echo e($role->id); ?>" class="btn btn-outline-secondary btn-sm btn-rounded">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/initiate-datatables.js')); ?>"></script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CEO\Desktop\Emman\Students\Pending\Terry\employee_attr\resources\views/admin/user-roles.blade.php ENDPATH**/ ?>