

<?php $__env->startSection('meta'); ?>
    <title>Users | Workday Time Clock</title>
    <meta name="description" content="Workday Users">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12 page-header">
            <h2 class="page-title">
                <?php echo e(__("Users")); ?>


                <a href="<?php echo e(url('admin/users/add')); ?>" class="btn btn-outline-primary btn-sm float-right">
                    <i class="fas fa-plus"></i><span class="button-with-icon"><?php echo e(__("Add")); ?></span>
                </a>

                <a href="<?php echo e(url('admin/user/roles')); ?>" class="btn btn-outline-success btn-sm mr-2 float-right">
                    <i class="fas fa-users"></i><span class="button-with-icon"><?php echo e(__("Roles")); ?></span>
                </a>
            </h2>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <table width="100%" class="table datatables-table custom-table-ui" data-order='[[ 0, "desc" ]]'>
                <thead>
                    <tr>
                        <th><?php echo e(__("Name")); ?></th>
                        <th><?php echo e(__("Email")); ?></th>
                        <th><?php echo e(__("Role")); ?></th>
                        <th><?php echo e(__("Type")); ?></th>
                        <th><?php echo e(__("Status")); ?></th>
                        <th><?php echo e(__("Actions")); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($users_roles)): ?>
                    <?php $__currentLoopData = $users_roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->name); ?></td>
                        <td><?php echo e($data->email); ?></td>
                        <td><?php echo e($data->role_name); ?></td>
                        <td> <?php if($data->acc_type == 2): ?> Admin <?php else: ?> Employee <?php endif; ?> </td>
                        <td>
                            <?php if($data->status == '1'): ?> 
                                Enabled
                            <?php else: ?>
                                Disabled
                            <?php endif; ?>
                        </td>
                        <td class="text-right">
                            <a href="<?php echo e(url('admin/users/edit')); ?>/<?php echo e($data->id); ?>" class="btn btn-outline-secondary btn-sm btn-rounded"><i class="fas fa-pen"></i></a>
                            <a href="<?php echo e(url('admin/users/delete')); ?>/<?php echo e($data->id); ?>" class="btn btn-outline-secondary btn-sm btn-rounded"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/initiate-datatables.js')); ?>"></script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CEO\Desktop\Emman\Students\Pending\Terry\employee_attr\resources\views/admin/users.blade.php ENDPATH**/ ?>