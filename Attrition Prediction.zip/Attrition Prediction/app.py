#Install Libraries
# import sklearn
import sklearn.externals as extjoblib
import joblib
# import joblib


from flask import Flask, request, jsonify
import traceback
import pandas as pd
import numpy as np

app = Flask(__name__)
employee_model = joblib.load("attrition_prediction.pkl") 
print ('Model loaded')
attrition_cols = joblib.load("attrition_columns.pkl") 
print ('Model columns loaded')
@app.route('/prediction', methods=['POST'])
#define function
def predict():
    if employee_model:
        
        try:
            
            json_ = request.json
            print(json_)
            query = pd.get_dummies(pd.DataFrame(json_,index=[0]))
            # query.to_frame('count')
            query = query.reindex(columns=attrition_cols, fill_value=0)
            predict = list(employee_model.predict(query))
            return jsonify({'prediction': str(predict)})
        except:
            return jsonify({'trace': traceback.format_exc()})
    
    else:
        
         print ('Model not good')
    return ('Model is not good')
if __name__ == '__main__':
    try:
        port = int(sys.argv[1])
    except:
        port = 12345 
   
app.run(debug=True)