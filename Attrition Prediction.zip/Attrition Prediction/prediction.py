from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import json

app = FastAPI()

class model_input(BaseModel):
   
    Age : float
    DailyRate  : float
    DistanceFromHome : float
    YearsWithCurrManager : float
    TotalWorkingYears : float
    HourlyRate : float
    PercentSalaryHike  : int
    NumCompaniesWorked  : int
    MonthlyIncome : float
    MonthlyRate : float
       
employee_model = joblib.load('attrition_prediction.pkl')

@app.post('/attrition_prediction') 
def stroke_pred(input_parameters: model_input):
    
    Age : float
    DailyRate  : float
    DistanceFromHome : float
    YearsWithCurrManager : float
    TotalWorkingYears : float
    HourlyRate : float
    PercentSalaryHike  : float
    NumCompaniesWorked  : float
    MonthlyIncome : float
    MonthlyRate : float
    input_data= input_parameters.json()
    input_dictionary = json.loads(input_data)  
    
    age = input_dictionary['Age']
    dailyRate = input_dictionary['DailyRate']
    distanceFromHome=input_dictionary['DistanceFromHome']
    yearsWithCurrManager= input_dictionary['YearsWithCurrManager']
    totalWorkingYears=input_dictionary['TotalWorkingYears']
    hourlyRate = input_dictionary['HourlyRate']
    percentSalaryHike = input_dictionary['PercentSalaryHike']
    numCompaniesWorked = input_dictionary['NumCompaniesWorked']
    monthlyIncome=input_dictionary['MonthlyIncome']
    monthlyRate= input_dictionary['MonthlyRate']
        
    input_list = [age, dailyRate, distanceFromHome, yearsWithCurrManager, totalWorkingYears, hourlyRate, percentSalaryHike,numCompaniesWorked,monthlyIncome,monthlyRate]
    
    prediction =employee_model.predict([input_list])
    
    if  (prediction[0]== 0):
        return 'Employee is predicted to churn'
    else:
        return 'Employee is predicted not to churn'